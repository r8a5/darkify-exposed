import discord
from discord.ext import commands
import asyncio
from datetime import datetime, timedelta
from google.cloud import vision
from google.oauth2 import service_account
from PIL import Image
import re
import configparser
import os
import logging

# Load config file safely
config_file_path = 'config/config.ini'
config = configparser.ConfigParser()

if os.path.exists(config_file_path):
    config.read(config_file_path)
else:
    raise FileNotFoundError(f"Config file not found at {config_file_path}")

# Make sure the token is properly assigned
MESSAGE_FILE = 'config/ad.txt'
with open(MESSAGE_FILE, 'r', encoding='utf8') as f:
    AD = f.read()
TOKEN = config['CONFIG'].get('TOKEN')
if not TOKEN:
    raise ValueError("Bot token not found in the config file.")

# Channel ID and other configurations
POSTING_CHANNEL_ID = int(config['SELFBOT'].get('PARTNERSHIP_CHANNEL_ID', 0))
USER_COOLDOWN_DURATION = int(config['SELFBOT'].get('USER_COOLDOWN_DURATION', 3600))
# Logging configuration
logging.basicConfig(filename='logs.txt', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Keywords the bot should respond to
KEYWORDS = ['partner', 'partnership', 'ally', 'collab', 'partners', 'partnerships', 'partener', 'parteners', 'pm']
INVITE_REGEX = r'(https?://)?(www\.)?(discord\.(gg|com/invite)/[a-zA-Z0-9]+)'
SERVER_COOLDOWN = int(config['SELFBOT'].get('SERVER_COOLDOWN', 1))
SERVER_COOLDOWN_DURATION = timedelta(days=SERVER_COOLDOWN)
SERVER_COOLDOWN_FILE = 'config/server_cooldowns.txt'
MEMBER_REQUIREMENT = int(config['SELFBOT'].get('MEMBER_REQUIREMENT', 300))

def load_server_cooldowns():
    """Load server cooldowns from file and return as a dictionary."""
    if not os.path.exists(SERVER_COOLDOWN_FILE):
        return {}
    cooldowns = {}
    with open(SERVER_COOLDOWN_FILE, 'r') as f:
        for line in f:
            server_id, timestamp_str = line.strip().split(',')
            cooldowns[int(server_id)] = datetime.fromisoformat(timestamp_str)
    return cooldowns

class CustomResponder(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.user_cooldowns = {}
        self.message_cooldowns = {}
        self.active_partnerships = {}
        self.cancellation_flags = {}
        self.server_cooldowns = load_server_cooldowns()
        self.first_reply = f"""## 🤝 Automated by [PartnerGo](<https://discord.gg/coolguys>)
> *The best selfbot on Discord to automate your partnerships.*

- Requirement: **{MEMBER_REQUIREMENT} members**.
- Type "**cancel**" to cancel anytime."""
        self.second_reply = '''Send me your **Discord server ad** to start the partnership.'''

    async def convert_seconds(self, seconds):
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        seconds = seconds % 60
        
        time_parts = []
        if hours > 0:
            time_parts.append(f"{hours} hour(s)")
        if minutes > 0:
            time_parts.append(f"{minutes} minute(s)")
        if seconds > 0 or not time_parts:  # Show 0 seconds if all other parts are zero
            time_parts.append(f"{seconds} second(s)")
        
        return ", ".join(time_parts)
    
    async def bot_typing(self, channel):
        TYPING_BOT = config['SELFBOT'].getboolean('TYPING_BOT')

        if TYPING_BOT == True:
            async with channel.typing():
                await asyncio.sleep(1)
        else:
            await asyncio.sleep(0.5)

    async def webhook_notification(self, message, invite_link_only):
        webhook_url = config['CONFIG'].get('WEBHOOK_URL')
        if webhook_url:
            embed = discord.Embed(
                title="✅ Partnership Successful!",
                description=f"> A partnership has been made in DMs.",
                color=discord.Color.green()
            )
            embed.add_field(name="Username:", value=f"```{message.author.name}```", inline=False)
            embed.add_field(name="User ID:", value=f"```{message.author.id}```", inline=False)
            embed.set_footer(text=f"PartnerGo, by Darkify.", icon_url="https://cdn.nest.rip/uploads/123b1441-39ec-49f7-bd50-f2f4bb601192.gif")
            
            try:
                webhook = discord.Webhook.from_url(webhook_url, adapter=discord.RequestsWebhookAdapter())
                webhook.send(content=invite_link_only, embed=embed)
            except Exception as e:
                logging.error(f"Failed to send webhook notification: {e}")

    async def analyze_image(self, file_path):
        """
        Analyzes an image to check if keywords from each category are found, if the ad was posted,
        and if the screenshot's aspect ratio suggests it is uncropped.
        """
        SERVICE_ACCOUNT_FILE = config['SELFBOT'].get('GOOGLE_CLOUD_JSON_FILE', None)

        # Organize keywords into separate groups
        AD_KEYWORD = config['SELFBOT'].get('AD_KEYWORD', None)
        AD_INVITE_LINK = config['SELFBOT'].get('AD_INVITE_LINK', None)
        AD_INVITE_CODE = AD_INVITE_LINK.split("/")[-1]

        KEYWORD_GROUPS = {
            "partnership": ["partner", "partners", "partnership", "partnerships", "ally", "collab", "collabs", "promotion", "promotions"],
            "ad": [AD_KEYWORD],
            "link": [AD_INVITE_LINK, AD_INVITE_CODE]
        }

        # Typical aspect ratios for common devices
        ASPECT_RATIOS = {
            "PC": 16 / 9,
            "Tablet": 4 / 3,
            "Phone": 19.5 / 9
        }
        TOLERANCE = 0.1  # Allowable deviation in aspect ratio (10%)

        # Set up Google Vision client
        credentials = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE)
        vision_client = vision.ImageAnnotatorClient(credentials=credentials)

        # Check the aspect ratio of the image
        with Image.open(file_path) as img:
            width, height = img.size
            image_aspect_ratio = width / height

        # Determine if the aspect ratio matches any of the common device aspect ratios within the tolerance
        aspect_ratio_match = any(
            abs(image_aspect_ratio - ratio) <= TOLERANCE * ratio
            for ratio in ASPECT_RATIOS.values()
        )

        # Perform text detection on the image file
        with open(file_path, 'rb') as image_file:
            content = image_file.read()
        image = vision.Image(content=content)
        response = vision_client.text_detection(image=image)
        texts = response.text_annotations

        if response.error.message:
            raise Exception(f"Google Vision API error: {response.error.message}")

        # Combine all detected text into one string
        detected_text = " ".join([text.description for text in texts])

        # Dictionary to store Boolean results for each category
        found_keywords = {
            category: any(keyword.lower() in detected_text.lower() for keyword in keywords)
            for category, keywords in KEYWORD_GROUPS.items()
        }

        # Determine if the ad was found based on each category being present
        ad_found = all(found_keywords.values())

        # Final decision for uncropped detection based on aspect ratio alone
        uncropped = aspect_ratio_match

        return found_keywords["partnership"], found_keywords["ad"], found_keywords["link"], ad_found, uncropped

    
    def save_server_cooldowns(self, cooldowns):
        """Save server cooldowns to a file."""
        with open(SERVER_COOLDOWN_FILE, 'w') as f:
            for server_id, expiry_time in cooldowns.items():
                f.write(f"{server_id},{expiry_time.isoformat()}\n")

    async def fetch_server_id_from_invite(self, invite_code):
        """Fetches the server ID from a Discord invite code."""
        try:
            invite = await self.bot.fetch_invite(invite_code)
            return invite.guild.id if invite.guild else None
        except discord.NotFound:
            return None
        except discord.HTTPException as e:
            logging.error(f"Error fetching server ID from invite: {e}")
            return None

    def is_server_in_cooldown(self, server_id):
        """Check if a server is in cooldown and return the remaining cooldown time if any."""
        cooldown_end = self.server_cooldowns.get(server_id)
        if cooldown_end and cooldown_end > datetime.now():
            return cooldown_end - datetime.now()
        return None
        
    def is_user_in_cooldown(self, user_id):
        """Check if the user's cooldown has expired or if they have an active partnership process.
        Returns the remaining time if they are still in cooldown, or None if not."""
        cooldown_end = self.user_cooldowns.get(user_id)
        if cooldown_end is None:
            return None  # Not in cooldown
        remaining_time = cooldown_end - datetime.now()
        if remaining_time.total_seconds() <= 0:
            del self.user_cooldowns[user_id]  # Remove expired cooldowns
            return None  # No cooldown
        return remaining_time  # Still in cooldown

    async def log_partnership(self, message, invite_link):
        """Logs successful partnerships to a file and sends a webhook notification."""
        # Extract only the Discord invite link
        invite_link_only = re.search(INVITE_REGEX, invite_link)
        invite_link_only = invite_link_only.group(0) if invite_link_only else "Invite link not found"

        # Log to file with UTF-8 encoding
        with open('logs.txt', 'a', encoding='utf-8') as log_file:
            log_file.write(f"Partnership completed with user: {message.author.name}, Server Invite: {invite_link_only}\n")

        # Webhook Notification
        await self.webhook_notification(message, invite_link_only)
    
    async def image_upload_confirmation(self, message, channel, author):
        checkmsg = await channel.send("# 🔎 ***Processing Screenshot...***")
        for attachment in message:
            if attachment.filename.lower().endswith(('png', 'jpg', 'jpeg')):
                # Download the image locally
                file_path = f'temp_{attachment.filename}'
                await attachment.save(file_path)
                # Analyze the image
                try:
                    partner, ad, link, ad_present, uncropped = await self.analyze_image(file_path)
                    if ad_present:
                        os.remove(file_path)
                        await checkmsg.delete()
                        is_ad_posted = True
                        return is_ad_posted, partner, ad, link, uncropped
                    else:
                        os.remove(file_path)
                        await checkmsg.delete()
                        is_ad_posted = False
                        return is_ad_posted, partner, ad, link, uncropped
                except Exception as e:
                    await channel.send(f"Error analyzing the image: {e}")
                    return False, None, None, None, None

    async def send_human_like_response(self, message):
        """Simulates a human-like response with typing and delay."""
        try:
            # First reply
            await self.bot_typing(message.channel)
            await  message.channel.send(self.first_reply)
            # Second reply after short typing
            await self.bot_typing(message.channel)
            await message.reply(self.second_reply)

        except discord.HTTPException as e:
            logging.error(f"Failed to send a message: {e}")

    async def fetch_member_count_from_invite(self, invite_code):
        """Fetches member count from a valid Discord invite."""
        try:
            invite = await self.bot.fetch_invite(invite_code)
            return invite.approximate_member_count
        except discord.NotFound:
            return None
        except discord.HTTPException as e:
            logging.error(f"Error fetching invite: {e}")
            return None

    async def wait_for_attachment_confirmation(self, user_id, channel, invite_message, server_id):
        """Waits for the user to send an attachment or to cancel the process."""
        # Check for valid messages for confirmation
        def check(m):
            return (m.author.id == user_id and isinstance(m.channel, discord.DMChannel) and 
                    (m.attachments or m.content.lower() == "cancel"))

        screenshot_limit = int(config['SELFBOT'].get('SCREENSHOT_LIMIT', 3))  # Set the limit for screenshots
        screenshot_count = 0  # Initialize the counter

        while True:
            try:
                # Wait for an attachment or cancellation
                message = await self.bot.wait_for('message', timeout=600, check=check)

                if message.content.lower() == "cancel":
                    await self.cancel_partnership(user_id, channel, reason="Partnership Canceled")
                    return  # Exit if canceled
                # Process the attachment
                if message.attachments:
                    screenshot_count += 1  # Increment the counter
                    is_ad_posted, partner, ad, link, uncropped = await self.image_upload_confirmation(message.attachments, message.channel, message.author)
                    if is_ad_posted:
                        posting_channel = self.bot.get_channel(POSTING_CHANNEL_ID)
                        if posting_channel:
                            await posting_channel.send(f"{invite_message.content}")
                        await self.bot_typing(channel)
                        cooldown_time = await self.convert_seconds(USER_COOLDOWN_DURATION)
                        await channel.send(f'''# ✅ **Success!**
> Your ad was posted successfully.
> For another partnership, type "**partner**" in {cooldown_time}.''')

                        await self.log_partnership(invite_message, invite_message.content)
                        # Set the cooldown after successful partnership start
                        self.user_cooldowns[invite_message.author.id] = datetime.now() + timedelta(seconds=USER_COOLDOWN_DURATION)
                        self.active_partnerships.pop(user_id, None)
                        self.server_cooldowns[server_id] = datetime.now() + SERVER_COOLDOWN_DURATION
                        self.save_server_cooldowns(self.server_cooldowns)
                        return  # Exit after successful posting

                    else:
                        if partner == True:
                            partner = "**Found** ✅"
                        else:
                            partner = "**Not Found** ❌"
                        if ad == True:
                            ad = "**Found** ✅"
                        else:
                            ad = "**Not Found** ❌"
                        if link == True:
                            link = "**Found** ✅"
                        else:
                            link = "**Not Found** ❌"
                        if uncropped == True:
                            uncropped = "**Yes** ✅"
                        else:
                            uncropped = "**No** ❌"

                        if screenshot_count <= 1:
                            await self.bot_typing(channel)
                            await channel.send(f'''# ⚠️ Incorrect Ad Posting. 
> **Make sure:**
> - You send a **full screenshot** (*uncropped*).
> - The **partnership channel** is visible.
> - The **server ad** is visible. (*or partially visible*)
> - The __**server invite link**__ is visible.
> Send a new screenshot or type "**cancel**" to cancel this partnership.
-# ℹ️ **{screenshot_limit - screenshot_count}** Tries Remaining.''')
                        else:
                            await self.bot_typing(channel)
                            await channel.send(f'''# ⚠️ Incorrect Ad Posting. 
> **Summary:**
> - Full Screenshot: {uncropped}
> - Partnership Channel: {partner}
> - Server Ad: {ad}
> - Server Invite Link: {link}
> Send a new screenshot or type "**cancel**" to cancel this partnership.
-# ℹ️ **{screenshot_limit - screenshot_count}** Tries Remaining.''')

                    # Check if the screenshot limit has been reached
                    if screenshot_count >= screenshot_limit:
                        await self.bot_typing(channel)
                        await channel.send('''# ❌ Max Attempts Reached.
> You've sent too many incorrect screenshots, the partnership was automatically canceled.
> If you want to start again, type "**partner**".''')
                        self.cancellation_flags[user_id] = True
                        self.active_partnerships.pop(user_id, None)
                        await asyncio.sleep(1)
                        self.cancellation_flags.pop(user_id, None)
                        self.user_cooldowns.pop(user_id, None)
                        return  # Exit if limit reached

            except asyncio.TimeoutError:
                if not self.cancellation_flags.get(user_id):
                    await self.cancel_partnership(user_id, channel, reason="Confirmation Expired")
                return  # Exit after timeout

            finally:
                # Clean up cancellation flag
                self.cancellation_flags.pop(user_id, None)

    async def wait_for_done_confirmation(self, user_id, channel, invite_message):
        """Waits for user to confirm they've posted the ad."""
        def check(m):
            return m.author.id == user_id and isinstance(m.channel, discord.DMChannel) and "done" in m.content.lower()

        try:
            if self.cancellation_flags.get(user_id):
                return

            await self.bot.wait_for('message', timeout=600, check=check)

            if self.cancellation_flags.get(user_id):
                return

            async with channel.typing():
                await asyncio.sleep(2)
            checkmsg = await channel.send("# 🔎 *Checking...*")
            await asyncio.sleep(3)

            posting_channel = self.bot.get_channel(POSTING_CHANNEL_ID)
            if posting_channel:
                await posting_channel.send(f"{invite_message.content}")

            await checkmsg.delete()
            async with channel.typing():
                await asyncio.sleep(2)
            cooldown_time = await self.convert_seconds(USER_COOLDOWN_DURATION)
            await channel.send(f'''# ✅ **Success!**
> Your ad was posted successfully.
> For another partnership, type "**partner**" in {cooldown_time}.''')

            await self.log_partnership(invite_message, invite_message.content)
            self.active_partnerships.pop(user_id, None)

        except asyncio.TimeoutError:
            if not self.cancellation_flags.get(user_id):
                    await self.cancel_partnership(user_id, channel, reason="Confirmation Expired")
            return  # Exit after timeout

        finally:
            # Clean up cancellation flag
            self.cancellation_flags.pop(user_id, None)
    
    async def wait_for_invite_link(self, user_id, channel, message):
        """Wait for a user to send a Discord server invite link and handle the invite."""
        # This function resets the cooldown for a user.
        def reset_cooldown(user_id):
            try:
                if user_id in self.user_cooldowns:
                    del self.user_cooldowns[user_id]
            except:
                pass

        # Define a check for incoming messages
        def check(m):
            return (m.author.id == user_id and isinstance(m.channel, discord.DMChannel) and 
                    (re.search(INVITE_REGEX, m.content) or m.content.lower() == "cancel"))

        while True:
            try:
                # Wait for the user to send either an invite link or a cancel command
                invite_message = await self.bot.wait_for('message', timeout=600, check=check)

                # Check if the user sent a cancel command
                if invite_message.content.lower() == "cancel":
                    reset_cooldown(user_id)  # Reset the cooldown here
                    break  # Break out of the loop on cancellation

                # If the message is not "cancel", process it as an invite link
                match = re.search(INVITE_REGEX, invite_message.content)
                if match:
                    invite_code = match.group(0).split('/')[-1]
                    member_count = await self.fetch_member_count_from_invite(invite_code)
                    server_id = await self.fetch_server_id_from_invite(invite_code)

                    if server_id:
                        remaining_time = self.is_server_in_cooldown(server_id)
                        if remaining_time:
                            await self.bot_typing(channel)
                            await channel.send(f'''# ⌛ Server on Cooldown
> A partnership was recently made with that server.
> Send a new link or type "**cancel**" to cancel this partnership
                                               
-# ℹ️ Cooldown: `{remaining_time.days} days & {remaining_time.seconds // 3600} hours`.''')
                            continue

                    # Re-check the cancellation flag before processing member count
                    if self.cancellation_flags.get(user_id):
                        reset_cooldown(user_id)  # Reset cooldown if cancelled
                        break  # Break out of the loop if canceled

                    if member_count is None:
                        await self.bot_typing(channel)
                        await channel.send('''# ⛔ Invalid Invite. 
> The invite link you provided is invalid.
> Send a new link or type "**cancel**" to cancel this partnership.''')
                        reset_cooldown(user_id)
                    elif member_count >= MEMBER_REQUIREMENT:
                        VALIDATION_TYPE = config['SELFBOT'].get('PARTNERSHIP_VALIDATION_TYPE')
                        if VALIDATION_TYPE == "AI":
                            await self.bot_typing(channel)
                            await channel.send(AD)
                            await self.bot_typing(channel)
                            await channel.send('''# ⌛ Send Screenshot.
> Post my ad in your server, then send a __**full screenshot**__.
> ⚠️ *Make sure that the* ***server invite link*** *and the* ***partnership channel*** *are visible.*   
### ✅ Using AI, I will see if you posted my ad correctly.''')
                            await self.wait_for_attachment_confirmation(user_id, channel, invite_message, server_id)
                            break  # Exit the loop after processing the invite
                        else:
                            await self.bot_typing(channel)
                            await channel.send(AD)
                            await self.bot_typing(channel)
                            await channel.send('''# ⌛ Post My Ad.
> You must post the ad above in your server.
> ⚠️ *I will join and check to see if the ad was posted.*  
### ✅ **When posted, reply with "**__**done**__**"**''')
                            await self.wait_for_done_confirmation(user_id, channel, invite_message)
                    else:
                        await self.bot_typing(channel)
                        await channel.send(f'''# ⚠️ Not Enough Members. 
> Your server only has **{member_count} members**, the required amount is **{MEMBER_REQUIREMENT}**.
> Send a new link or type "**cancel**" to cancel this partnership.''')
                        reset_cooldown(user_id)
                else:
                    await self.bot_typing(channel)
                    await channel.send('''# ⛔ Invalid Invite. 
> The invite you provided is invalid.
> Send a new link or type "**cancel**" to cancel this partnership.''')
                    reset_cooldown(user_id)

            except asyncio.TimeoutError:              
                reset_cooldown(user_id)
                await self.cancel_partnership(user_id, channel, reason="No Invite Sent")
                break  # Exit the loop on timeout
            except discord.HTTPException as e:
                logging.error(f"Error handling invite: {e}")
                reset_cooldown(user_id)
                break  # Exit the loop on HTTP error

    async def handle_confirmation(self, message):
        """Handles confirmation using reactions."""
        await self.bot_typing(message.channel)
        confirm_msg = await message.channel.send("""# 🤝 __**Want to partner?**__
> ✅ - **Yes**, I want to partner.
> ❌ - **No**, I don't want to partner.""")

        await confirm_msg.add_reaction("✅")
        await confirm_msg.add_reaction("❌")

        def check(reaction, user):
            return user == message.author and str(reaction.emoji) in ['✅', '❌'] and reaction.message.id == confirm_msg.id

        try:
            reaction, user = await self.bot.wait_for('reaction_add', timeout=300.0, check=check)

            # Delete the confirmation message after the reaction
            await confirm_msg.delete()

            if str(reaction.emoji) == '✅':
                await self.send_human_like_response(message)
                await self.wait_for_invite_link(message.author.id, message.channel, message)
            else:
                await self.cancel_partnership(message.author.id, message.channel, reason="Partnership Canceled")
                # del self.active_partnerships[message.author.id]

        except asyncio.TimeoutError:
            # Delete the confirmation message if the timeout occurs
            await confirm_msg.delete()

    async def cancel_partnership(self, user_id, channel, reason):
        """Cancels an ongoing partnership process and resets all related states."""
        # Set the cancellation flag to True to halt any ongoing processes
        self.cancellation_flags[user_id] = True

        # Remove any active partnership and cooldown if they exist
        self.active_partnerships.pop(user_id, None)
        self.user_cooldowns.pop(user_id, None)

        # Inform the user about the cancellation
        await self.bot_typing(channel)
        if reason == "Partnership Canceled":
            await channel.send('''# ❌ Partnership Canceled.
> You decided to cancel the partnership.
> If you want to start again, type "**partner**".''')
        elif reason == "No Invite Sent":
            await channel.send('''# ⚠️ No Invite Sent. 
> You did not send any invite links.
> Your partnership was canceled, type "**partner** to start it again".''')
        elif reason == "Confirmation Expired":
            await channel.send('''# ⚠️ Confirmation Expired. 
> You did not send a screenshot in time.
> Your partnership was canceled, type "**partner** to start it again".''')
        
        # Reset the cancellation flag after the cancellation is complete to avoid interference in future partnerships
        await asyncio.sleep(1)
        self.cancellation_flags.pop(user_id, None)
        
    @commands.Cog.listener()
    async def on_message(self, message):
        # Ignore messages from bots or self
        if message.author == self.bot.user or message.author.bot:
            return

        # Process partnership keywords
        if isinstance(message.channel, discord.DMChannel):
            current_time = datetime.now()

            # Check for already active partnership
            if any(keyword in message.content.lower() for keyword in KEYWORDS):
                if message.author.id in self.active_partnerships:
                    last_message_time = self.message_cooldowns.get(message.author.id)

                    # Check cooldown for "You are already in a partnership process." message
                    if last_message_time is None or (current_time - last_message_time).total_seconds() > 10:
                        self.message_cooldowns[message.author.id] = current_time
                    return  # Exit since the user is already in a process

                # Check if the user is in cooldown for the general partnership process
                remaining_time = self.is_user_in_cooldown(message.author.id)
                if remaining_time:
                    last_cooldown_time = self.message_cooldowns.get(message.author.id)

                    # Check cooldown for "Cooldown Active." message
                    if last_cooldown_time is None or (current_time - last_cooldown_time).total_seconds() > 10:
                        await self.bot_typing(message.channel)
                        await message.channel.send(f'''# ⚠️ Cooldown Active.
> You need to wait **{remaining_time.seconds // 60} minutes and {remaining_time.seconds % 60} seconds** before starting another partnership.
> How about you join [**Darkify**](<https://discord.gg/darkify>) while waiting?''')
                        self.message_cooldowns[message.author.id] = current_time
                    return  # Exit as the user is still on cooldown

                # If no cooldown, initiate new partnership process
                if not self.is_user_in_cooldown(message.author.id):
                    self.cancellation_flags[message.author.id] = False
                    self.active_partnerships[message.author.id] = True
                    await self.handle_confirmation(message)

            # Handle cancellation only if the partnership process is actively ongoing
            elif "cancel" in message.content.lower() and message.author.id in self.active_partnerships:
                await self.cancel_partnership(message.author.id, message.channel, reason="Partnership Canceled")
                
def setup(bot):
    bot.add_cog(CustomResponder(bot))

intents = discord.Intents.all()
intents.messages = True
intents.dm_messages = True
intents.guilds = True

bot = commands.Bot(command_prefix="!", intents=intents)

setup(bot)

if __name__ == "__main__":
    bot.run(TOKEN, bot=False)